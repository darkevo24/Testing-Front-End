module.exports = { ReactComponent: 'IconMock' };
