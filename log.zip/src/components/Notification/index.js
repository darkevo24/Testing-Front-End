import Notify from './Notify';
import NotificationComponent from './Notification';

export const Notification = NotificationComponent;
export default Notify;
