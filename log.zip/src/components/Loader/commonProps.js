export const commonColorProps = {
  backgroundColor: '#eaeced',
  foregroundColor: '#ffffff',
};

export const commonHeaderColorProps = {
  backgroundColor: '#0f263b',
  foregroundColor: '#2c3e4d',
};
