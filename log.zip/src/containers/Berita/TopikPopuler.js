import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ReactComponent as StarRed } from 'assets/star-red.svg';
import { ReactComponent as ArrowRightRed } from 'assets/arrow-right-red.svg';
import styled from 'styled-components';
import { getPopularTopic, popularTopicSelector } from './reducer';

const Wrapper = styled.div`
  margin-bottom: 40px;
`;

const TopikItem = styled.div`
  display: flex;
  align-items: center;
  border-bottom: 1px solid #e1e2ea;
  padding: 16px 0;

  &.child {
    justify-content: space-between;
    padding: 16px;
  }
`;

const Title = styled.span`
  font-weight: bold;
  font-size: 16px;
  color: #2d2627;
  margin-left: 12px;
`;

const TopikPopuler = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getPopularTopic('populer/tagline'));
  }, []);
  const { records: dataPopularTopic } = useSelector(popularTopicSelector);

  return (
    <Wrapper>
      <TopikItem>
        <StarRed />
        <Title>Topik Populer</Title>
      </TopikItem>
      {dataPopularTopic.length > 0 &&
        dataPopularTopic.map((value, index) => {
          return (
            <TopikItem className="child" key={index}>
              <span>{value.keterangan}</span>
              <ArrowRightRed />
            </TopikItem>
          );
        })}
    </Wrapper>
  );
};

export default TopikPopuler;
